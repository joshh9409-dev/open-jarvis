package com.openjarvis.automation

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val command: String,
    val scheduleType: String,
    val scheduleHour: Int = 0,
    val scheduleMinute: Int = 0,
    val scheduleDayOfWeek: Int = 0,
    val scheduleIntervalMs: Long = 0,
    val enabled: Boolean = true,
    val lastRun: Long? = null,
    val lastResult: String? = null,
    val runCount: Int = 0
)

fun AutomationManager.Automation.toEntity(): AutomationEntity {
    val schedule = schedule
    return when (schedule) {
        is AutomationManager.AutomationSchedule.Daily -> AutomationEntity(
            id, name, command, "daily", schedule.hour, schedule.minute,
            0, 0, enabled, lastRun, lastResult, runCount
        )
        is AutomationManager.AutomationSchedule.Weekly -> AutomationEntity(
            id, name, command, "weekly", schedule.hour, schedule.minute,
            schedule.dayOfWeek, 0, enabled, lastRun, lastResult, runCount
        )
        is AutomationManager.AutomationSchedule.Interval -> AutomationEntity(
            id, name, command, "interval", 0, 0,
            0, schedule.intervalMs, enabled, lastRun, lastResult, runCount
        )
        is AutomationManager.AutomationSchedule.Once -> AutomationEntity(
            id, name, command, "once", 0, 0,
            0, 0, enabled, schedule.atMs, lastResult, runCount
        )
    }
}

fun AutomationEntity.toAutomation(): AutomationManager.Automation {
    val schedule = when (scheduleType.lowercase()) {
        "daily" -> AutomationManager.AutomationSchedule.Daily(scheduleHour, scheduleMinute)
        "weekly" -> AutomationManager.AutomationSchedule.Weekly(scheduleDayOfWeek, scheduleHour, scheduleMinute)
        "interval" -> AutomationManager.AutomationSchedule.Interval(scheduleIntervalMs.coerceAtLeast(1L))
        "once" -> AutomationManager.AutomationSchedule.Once(lastRun ?: System.currentTimeMillis())
        else -> AutomationManager.AutomationSchedule.Once(lastRun ?: System.currentTimeMillis())
    }
    return AutomationManager.Automation(
        id = id,
        name = name,
        command = command,
        schedule = schedule,
        enabled = enabled,
        lastRun = lastRun,
        lastResult = lastResult,
        runCount = runCount
    )
}

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automations ORDER BY name")
    suspend fun getAll(): List<AutomationEntity>

    @Query("SELECT * FROM automations WHERE id = :id")
    suspend fun getById(id: String): AutomationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(automation: AutomationEntity)

    @Update
    suspend fun update(automation: AutomationEntity)

    @Query("DELETE FROM automations WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [AutomationEntity::class], version = 1, exportSchema = false)
abstract class AutomationDB : RoomDatabase() {
    abstract fun automationDao(): AutomationDao

    companion object {
        @Volatile private var INSTANCE: AutomationDB? = null

        fun getInstance(context: Context): AutomationDB {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AutomationDB::class.java,
                    "automations.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

class AutomationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("automation_id") ?: return Result.failure()
        inputData.getString("automation_command") ?: return Result.failure()

        return try {
            val dao = AutomationDB.getInstance(applicationContext).automationDao()
            val entity = dao.getById(id) ?: return Result.failure()
            dao.update(
                entity.copy(
                    lastRun = System.currentTimeMillis(),
                    lastResult = "success",
                    runCount = entity.runCount + 1
                )
            )
            Result.success()
        } catch (_: Exception) {
            Result.failure()
        }
    }
}
