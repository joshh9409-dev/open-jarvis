package com.openjarvis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VoidColor {
    val Violet = Color(0xFF9B5CFF)
    val VioletDim = Color(0xFF6F3DBA)
    val Cyan = Color(0xFF35D9FF)
    val Green = Color(0xFF35E58C)
    val Red = Color(0xFFFF4D6D)
    val Amber = Color(0xFFFFC857)

    val Void950 = Color(0xFF08060D)
    val Void900 = Color(0xFF100C18)
    val Void800 = Color(0xFF191324)
    val Void700 = Color(0xFF251B35)
    val Void600 = Color(0xFF34264A)

    val TextPrimary = Color(0xFFF7F2FF)
    val TextSecondary = Color(0xFFB8ACC8)
    val TextDisabled = Color(0xFF756B82)

    val BorderSubtle = Color(0xFF3A2B50)
    val BorderGlow = Color(0xFF8B52E8)
}

private val VoidDarkColors = darkColorScheme(
    primary = VoidColor.Violet,
    onPrimary = Color.White,
    secondary = VoidColor.Cyan,
    onSecondary = Color.Black,
    background = VoidColor.Void950,
    onBackground = VoidColor.TextPrimary,
    surface = VoidColor.Void900,
    onSurface = VoidColor.TextPrimary,
    error = VoidColor.Red,
    onError = Color.White
)

@Composable
fun OpenJarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VoidDarkColors,
        content = content
    )
}
